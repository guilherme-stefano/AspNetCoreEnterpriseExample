﻿using System;

namespace NSE.Core
{
    public class Class1
    {
    }
}
