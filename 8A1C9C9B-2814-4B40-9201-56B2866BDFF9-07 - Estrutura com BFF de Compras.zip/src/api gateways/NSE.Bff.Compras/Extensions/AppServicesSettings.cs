﻿namespace NSE.Bff.Compras.Extensions
{
    public class AppServicesSettings
    {
        public string CatalogoUrl { get; set; }
        public string CarrinhoUrl { get; set; }
        public string PedidoUrl { get; set; }
        public string PagamentoUrl { get; set; }
    }
}