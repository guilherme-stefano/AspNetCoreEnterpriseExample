﻿namespace NSE.Pagamentos.API.Models
{
    public enum TipoPagamento
    {
        CartaoCredito = 1,
        Boleto
    }
}