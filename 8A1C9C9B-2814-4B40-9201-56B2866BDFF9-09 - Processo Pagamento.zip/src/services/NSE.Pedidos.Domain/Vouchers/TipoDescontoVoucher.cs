﻿namespace NSE.Pedidos.Domain
{
    public enum TipoDescontoVoucher
    {
        Porcentagem = 0,
        Valor = 1
    }
}