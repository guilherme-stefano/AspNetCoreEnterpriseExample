﻿namespace NSE.WebApp.MVC.Extensions
{
    public class AppSettings
    {
        public string AutenticacaoUrl { get; set; }
        public string CatalogoUrl { get; set; }
        public string CarrinhoUrl { get; set; }
    }
}