﻿namespace NSE.Pagamentos.NerdsPag
{
    public enum PaymentMethod
    {
        CreditCard = 1,
        Billet
    }
}