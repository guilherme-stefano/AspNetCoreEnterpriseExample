﻿using NSE.WebAPI.Core.Controllers;

namespace NSE.Pagamentos.API.Controllers
{
    public class PagamentoController : MainController
    {
        
    }
}