﻿namespace NSE.Core.Messages.Integration
{
    public abstract class IntegrationEvent : Event
    {
        
    }
}