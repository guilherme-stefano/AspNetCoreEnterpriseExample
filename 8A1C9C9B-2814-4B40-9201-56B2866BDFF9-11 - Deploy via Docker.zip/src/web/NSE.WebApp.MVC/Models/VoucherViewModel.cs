﻿namespace NSE.WebApp.MVC.Models
{
    public class VoucherViewModel
    {
        public string Codigo { get; set; }
    }
}