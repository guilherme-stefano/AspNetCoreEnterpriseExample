﻿namespace NSE.WebAPI.Core.Identidade
{ 
    public class AppSettings
    {
        public string AutenticacaoJwksUrl { get; set; }
    }
}