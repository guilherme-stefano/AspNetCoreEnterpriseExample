﻿namespace NSE.Identidade.API.Extensions
{
    public class AppTokenSettings
    {
        public int RefreshTokenExpiration { get; set; }
    }
}